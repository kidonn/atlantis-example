import base64

import boto3
from botocore.exceptions import ClientError

import logger
from env import REGION

log = logger.instance('Util')


class Util:
    @classmethod
    def get_secret(cls, secret_name):
        session = boto3.session.Session()
        client = session.client(
            service_name='secretsmanager',
            region_name=REGION
        )
        try:
            get_secret_value_response = client.get_secret_value(SecretId=secret_name)
        except ClientError as e:
            log.error(e.args[0])
        else:
            if 'SecretString' in get_secret_value_response:
                return get_secret_value_response['SecretString']
            else:
                return base64.b64decode(get_secret_value_response['SecretBinary'])

import json

import requests

import logger
from env import FCM_DATA
from util import Util

log = logger.instance('HttpRequest')

__fcm_data = json.loads(Util.get_secret(FCM_DATA))


def push_notification(device_token, title, body, status):
    if __fcm_data:
        _host = __fcm_data.get('fcm_host')
        _auth = __fcm_data.get('authorization')

        headers = {
            'Content-Type': 'application/json',
            'Authorization': _auth
        }

        body = {
            'to': device_token,
            'data': {
                'title': title,
                'body': body,
                'status': status
            },
            'webpush': {
                'headers': {
                    'Urgency': 'high'
                }
            }
        }
        response = requests.post(url=_host, headers=headers, json=body)
        log.info(f'FCM push result {response}')
    else:
        log.error('Could not find FCM data')

import logger
from http_request import push_notification

log = logger.instance('Lambda function')

SUCCESS = 'SUCCESS'


def lambda_handler(event, context):
    log.info(f'EVENT DETAILS: {event}')
    details = event['detail']
    if details:
        device_token = details['deviceToken']
        if device_token is None:
            log.warn("Device token not found, does not trigger FCM")
            return

        transfer_group_id = details['transferGroupId']
        log.info(f'Handling push notification for this transfer group {transfer_group_id}, device id {device_token}')
        bulk_flag = bool(details['bulkFlag'])
        status = details['status']
        handle_push_notification(is_bulk=bulk_flag, status=status, details=details)


def handle_push_notification(is_bulk, status, details):
    if is_bulk is True:
        bulk_push_notification(details)
    else:
        send_money_push_notification(status, details['deviceToken'])


def bulk_push_notification(details):
    has_failed = bool(details['hasFailed'])
    has_success = bool(details['hasSuccess'])
    device_token = details['deviceToken']

    log.info(f'Handling bulk notification, has success {has_success}, has failed {has_failed}')
    if has_failed is True and has_success is False:
        log.info(f'Push notification for all failed')
        push_notification(
            device_token=device_token,
            body='Wallet Update Failed',
            title='Transaction Failed',
            status='error')
    elif has_failed is False and has_success is True:
        log.info('Push notification for all complete')
        push_notification(
            device_token=device_token,
            body='Wallet Update',
            title='Transaction Complete',
            status='success')
    elif has_failed is True and has_success is True:
        log.info('Push notification for partial success')
        push_notification(
            device_token=device_token,
            body='Wallet Update',
            title='All transactions could not be completed. Please check your e-mail for details',
            status='error')


def send_money_push_notification(status, device_token):
    if SUCCESS == status:
        push_notification(
            device_token=device_token,
            body='Wallet Update',
            title='Transaction Complete',
            status='success')
    else:
        push_notification(
            device_token=device_token,
            body='Transaction Failed',
            title='Transaction Failed',
            status='error')

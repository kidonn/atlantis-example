import os

REGION = os.environ.get('DEFAULT_REGION')
FCM_DATA = os.environ.get('FCM_DATA')

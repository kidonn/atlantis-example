import logging

loggers = {}


def instance(name):
    global loggers

    if loggers.get(name):
        return loggers.get(name)
    else:
        log = logging.getLogger(name)
        log.propagate = False
        log.setLevel(logging.INFO)
        handler = logging.StreamHandler()
        formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
        handler.setFormatter(formatter)
        log.addHandler(handler)
        loggers[name] = log

        return log
